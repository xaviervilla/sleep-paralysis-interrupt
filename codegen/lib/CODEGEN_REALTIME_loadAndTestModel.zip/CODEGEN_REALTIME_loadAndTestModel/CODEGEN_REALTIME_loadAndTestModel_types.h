/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * CODEGEN_REALTIME_loadAndTestModel_types.h
 *
 * Code generation for function 'CODEGEN_REALTIME_loadAndTestModel_types'
 *
 */

#ifndef CODEGEN_REALTIME_LOADANDTESTMODEL_TYPES_H
#define CODEGEN_REALTIME_LOADANDTESTMODEL_TYPES_H

/* Include files */
#include "rtwtypes.h"
#endif

/* End of code generation (CODEGEN_REALTIME_loadAndTestModel_types.h) */
