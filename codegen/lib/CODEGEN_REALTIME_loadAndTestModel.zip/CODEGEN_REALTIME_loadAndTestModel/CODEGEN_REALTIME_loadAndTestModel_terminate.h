/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * CODEGEN_REALTIME_loadAndTestModel_terminate.h
 *
 * Code generation for function 'CODEGEN_REALTIME_loadAndTestModel_terminate'
 *
 */

#ifndef CODEGEN_REALTIME_LOADANDTESTMODEL_TERMINATE_H
#define CODEGEN_REALTIME_LOADANDTESTMODEL_TERMINATE_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "CODEGEN_REALTIME_loadAndTestModel_types.h"

/* Function Declarations */
extern void CODEGEN_REALTIME_loadAndTestModel_terminate(void);

#endif

/* End of code generation (CODEGEN_REALTIME_loadAndTestModel_terminate.h) */
