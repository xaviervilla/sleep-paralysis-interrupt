/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: CODEGEN_standalonePredictor_types.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 25-Nov-2019 01:41:57
 */

#ifndef CODEGEN_STANDALONEPREDICTOR_TYPES_H
#define CODEGEN_STANDALONEPREDICTOR_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for CODEGEN_standalonePredictor_types.h
 *
 * [EOF]
 */
